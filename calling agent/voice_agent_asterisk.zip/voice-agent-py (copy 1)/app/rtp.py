# app/rtp.py
import struct
from dataclasses import dataclass

RTP_VERSION = 2

@dataclass
class RtpState:
    seq: int = 1
    ts: int = 0
    ssrc: int = 0x12345678

def build_rtp(payload: bytes, st: RtpState, payload_type: int = 0) -> bytes:
    """Build RTP packet with 12-byte header + payload"""
    vpxcc = (RTP_VERSION << 6)
    mpt = payload_type
    header = struct.pack("!BBHII", vpxcc, mpt, st.seq & 0xFFFF, st.ts & 0xFFFFFFFF, st.ssrc)
    st.seq = (st.seq + 1) & 0xFFFF
    st.ts = (st.ts + 160) & 0xFFFFFFFF  # 20ms at 8kHz for PCMU
    return header + payload

def parse_rtp(packet: bytes) -> bytes:
    """Extract payload from RTP packet"""
    if len(packet) < 12:
        return b""
    return packet[12:]
