"""
Main entry point with connection pooling for instant call handling
Orchestrates all components and handles incoming calls
"""

import asyncio
import zlib
from uuid import uuid4
from aiohttp import web

from .settings import *
from .ari import Ari
from .realtime import RealtimeBridge
from .realtime_pool import RealtimeConnectionPool
from .observability import web_app, calls_total, active_calls

UDP_BASE = 42000
UDP_RANGE = 500

# Global connection pool
connection_pool = None


async def handle_event(ari: Ari, evt: dict):
    """Handle incoming call events with INSTANT response"""
    global connection_pool
    
    t = evt.get("type")
    if t != "StasisStart":
        return

    ch = evt["channel"]["id"]
    print(f"\n{'='*60}")
    print(f"[EVENT] 📞 Incoming call: {ch}")
    print(f"{'='*60}")

    # Deterministic UDP port for this call
    udp_port = UDP_BASE + (zlib.crc32(ch.encode()) % UDP_RANGE)

    calls_total.inc()
    active_calls.inc()

    try:
        # Create mixing bridge
        bridge_id = f"b-{ch}"
        await ari.bridge_create(bridge_id)
        await ari.bridge_add(bridge_id, ch)
        print(f"[EVENT] ✅ Bridge created: {bridge_id}")

        # Create ExternalMedia channel for RTP
        em_id = f"ext-{uuid4()}"
        em = await ari.external_media(
            em_id,
            host=f"127.0.0.1:{udp_port}",
            fmt="ulaw",
            direction="both"
        )
        await ari.bridge_add(bridge_id, em["id"])
        print(f"[EVENT] ✅ ExternalMedia created: {em['id']}")

        # Get RTP connection details
        rtp_port = await ari.get_var(em["id"], "UNICASTRTP_LOCAL_PORT")
        rtp_addr = await ari.get_var(em["id"], "UNICASTRTP_LOCAL_ADDRESS")
        
        if not (rtp_addr and rtp_port):
            raise RuntimeError("Failed to get RTP variables")

        print(f"[EVENT] 🔊 RTP: {rtp_addr}:{rtp_port} ↔ UDP: {udp_port}")

        # Start RealtimeBridge with pooled connection
        print(f"[EVENT] 🚀 Starting RealtimeBridge...")
        rb = RealtimeBridge(
            connection_pool=connection_pool,  # Use pre-warmed pool!
            model=OPENAI_MODEL,
            voice=OPENAI_VOICE,
            asterisk_rtp_host=rtp_addr,
            asterisk_rtp_port=int(rtp_port),
            udp_bind_port=udp_port
        )
        await rb.start()

    except Exception as e:
        print(f"[EVENT] ❌ Error handling call {ch}: {e}")
        import traceback
        traceback.print_exc()
    finally:
        active_calls.dec()
        print(f"[EVENT] 👋 Call ended: {ch}\n")


async def main():
    """Main application entry point"""
    global connection_pool
    
    print("\n" + "="*60)
    print("🎙️  AI VOICE AGENT - ULTRA LOW LATENCY")
    print("     STABLE + FAST + CLEAN AUDIO")
    print("="*60 + "\n")
    
    # STEP 1: Initialize connection pool (pre-warm connections)
    print("[INIT] Initializing OpenAI connection pool...")
    connection_pool = RealtimeConnectionPool(
        openai_key=OPENAI_API_KEY,
        model=OPENAI_MODEL,
        voice=OPENAI_VOICE,
        pool_size=5  # Keep 5 connections ready
    )
    await connection_pool.start()
    
    # STEP 2: Start metrics/health server
    app = web_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, SERVICE_HOST, SERVICE_PORT)
    await site.start()
    print(f"[INIT] ✅ Metrics: http://{SERVICE_HOST}:{SERVICE_PORT}/metrics")
    print(f"[INIT] ✅ Health: http://{SERVICE_HOST}:{SERVICE_PORT}/healthz")

    # STEP 3: Connect to Asterisk ARI
    ari = Ari(ASTERISK_ARI_URL, ASTERISK_ARI_USER, ASTERISK_ARI_PASS, STASIS_APP)
    print(f"[INIT] Connecting to Asterisk ARI...")
    
    print("\n" + "="*60)
    print("✅ SYSTEM READY - Waiting for calls...")
    print("="*60 + "\n")

    # STEP 4: Listen for call events
    try:
        await ari.events(lambda e: asyncio.create_task(handle_event(ari, e)))
    except Exception as e:
        print(f"[ERROR] ARI connection failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Cleanup
        print("\n[SHUTDOWN] Stopping connection pool...")
        await connection_pool.stop()
        print("[SHUTDOWN] Goodbye! 👋\n")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user")