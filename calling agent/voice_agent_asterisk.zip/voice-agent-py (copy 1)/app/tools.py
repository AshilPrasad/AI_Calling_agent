# app/tools.py
import json

TOOLS_SCHEMA = [
    {
        "type": "function",
        "name": "create_ticket",
        "description": "Create a support ticket with minimal details",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "phone": {"type": "string"},
                "summary": {"type": "string"}
            },
            "required": ["name", "summary"]
        }
    }
]

async def handle_tool_call(name: str, arguments_json: str):
    """Handle function/tool calls from OpenAI Realtime"""
    if name == "create_ticket":
        args = json.loads(arguments_json or "{}")
        # TODO: write to your CRM/helpdesk
        ticket_id = "TCK-" + (args.get("phone") or "anon")
        print(f"[INFO] Created ticket {ticket_id}: {args.get('summary')}")
        return {"ticket_id": ticket_id, "status": "created"}
    return {"error": "unknown tool"}
