# app/observability.py
from prometheus_client import Counter, Histogram, Gauge, CollectorRegistry, CONTENT_TYPE_LATEST, generate_latest
from aiohttp import web

reg = CollectorRegistry()
calls_total = Counter("calls_total", "Total answered calls", registry=reg)
rtp_in_bytes = Counter("rtp_in_bytes", "RTP bytes received", registry=reg)
rtp_out_bytes = Counter("rtp_out_bytes", "RTP bytes sent", registry=reg)
ws_send_latency = Histogram(
    "realtime_ws_send_ms",
    "WS send latency (ms)",
    buckets=[10, 50, 100, 250, 500, 1000],
    registry=reg
)
active_calls = Gauge("active_calls", "Current active calls", registry=reg)

async def metrics(request):
    return web.Response(text=generate_latest(reg).decode(), content_type=CONTENT_TYPE_LATEST)

async def health(request):
    return web.Response(text="ok")

def web_app():
    app = web.Application()
    app.router.add_get("/metrics", metrics)
    app.router.add_get("/healthz", health)
    return app
