# app/ari.py
import aiohttp
import asyncio
import json
import websockets
import base64
from typing import Callable, Awaitable

class Ari:
    def __init__(self, base_url: str, user: str, password: str, app: str):
        self.base = base_url.rstrip("/")
        self.auth_user = user
        self.auth_pass = password
        self.app = app

    def _basic_auth_header(self):
        creds = f"{self.auth_user}:{self.auth_pass}".encode()
        return {"Authorization": "Basic " + base64.b64encode(creds).decode()}

    # WebSocket events
    async def events(self, handler: Callable[[dict], Awaitable[None]]):
        ws_url = self.base.replace("http", "ws") + f"/events?app={self.app}"
        async with websockets.connect(ws_url, extra_headers=self._basic_auth_header()) as ws:
            print("[DEBUG] Connected to ARI WebSocket")
            async for message in ws:
                try:
                    evt = json.loads(message)
                    await handler(evt)
                except Exception as e:
                    print(f"[ERROR] Error parsing event: {e}")
                    continue

    # HTTP REST POST helper
    async def post(self, path: str, **params):
        url = f"{self.base}{path}"
        async with aiohttp.ClientSession(auth=aiohttp.BasicAuth(self.auth_user, self.auth_pass)) as sess:
            async with sess.post(url, params=params) as resp:
                if resp.status >= 300:
                    raise RuntimeError(await resp.text())
                return await resp.json(content_type=None)

    async def get_var(self, channel_id: str, variable: str) -> str:
        async with aiohttp.ClientSession(auth=aiohttp.BasicAuth(self.auth_user, self.auth_pass)) as sess:
            async with sess.get(f"{self.base}/channels/{channel_id}/variable", params={"variable": variable}) as resp:
                j = await resp.json()
                return j.get("value", "")

    async def bridge_create(self, bridge_id: str):
        return await self.post("/bridges", type="mixing", bridgeId=bridge_id)

    async def bridge_add(self, bridge_id: str, channel_id: str):
        async with aiohttp.ClientSession(auth=aiohttp.BasicAuth(self.auth_user, self.auth_pass)) as sess:
            async with sess.post(f"{self.base}/bridges/{bridge_id}/addChannel", params={"channel": channel_id}) as resp:
                if resp.status >= 300:
                    raise RuntimeError(await resp.text())

    async def external_media(self, channel_id: str, host: str, fmt="pcmu", direction="both"):
        return await self.post(
            "/channels/externalMedia",
            app=self.app,
            channelId=channel_id,
            external_host=host,
            format=fmt,
            direction=direction
        )

    async def continue_in_dialplan(self, channel_id: str, context: str, exten: str, priority: int = 1):
        async with aiohttp.ClientSession(auth=aiohttp.BasicAuth(self.auth_user, self.auth_pass)) as sess:
            async with sess.post(
                f"{self.base}/channels/{channel_id}/continue",
                params={"context": context, "extension": exten, "priority": priority}
            ) as resp:
                if resp.status >= 300:
                    raise RuntimeError(await resp.text())
