# app/settings.py
import os
from dotenv import load_dotenv
load_dotenv()

ASTERISK_ARI_URL = os.getenv("ASTERISK_ARI_URL", "http://127.0.0.1:8088/ari")
ASTERISK_ARI_USER = os.getenv("ASTERISK_ARI_USER", "voice-agent")
ASTERISK_ARI_PASS = os.getenv("ASTERISK_ARI_PASS", "CHANGE_ME")
STASIS_APP = os.getenv("STASIS_APP", "voice-agent")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-realtime-preview-2024-12-17")
OPENAI_VOICE = os.getenv("OPENAI_VOICE", "alloy")

SERVICE_HOST = os.getenv("SERVICE_HOST", "0.0.0.0")
SERVICE_PORT = int(os.getenv("SERVICE_PORT", "3000"))
